
#input details here and you are good to go!


email = ""
password = ""

firstName = ""
lastName = ""
gradeLevel = 12